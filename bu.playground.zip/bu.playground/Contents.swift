//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var cadena = "a"
type(of: cadena)

var message = "Hola" + "mundo"
var name = "HO"

message += name
