//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

struct Alumno{
    var numCuenta : String
    var nombre : String
    var edad : Int
    
    func estudiar(){
        print("Alumno estudiando")
    }
    func leer(){
        print("Alumno leyendo")
    }
//INCIALIZADOR = INIT
    init(nombre: String, numCuenta: String, edad: Int) {
        self.nombre = nombre
        self.edad = edad
        self.numCuenta = "00000"
    }
    mutating func modicaEdad() {
        self.edad = self.edad + 1
        
    }
}
//CLASS Y STRUCT SON DIFERENTES CLASS TRABAJA CON VALORES DE REFERENCIA Y STRUCT POR VALOR
// CLASES CUANDO NECESITEMOS HERENCIA ESTA ES ÚNICA
// REFERENCIA INSTANCIA Y COPIA
//contexto dentro de la estructura self
//EN LAS ESTRUCTURAS NO HAY HERENCIAS
//las fucniones no pueden modificar los datos, para ello tenemos que poner mutating
//un objeto tiene propiedades sin embargo estas pueden ser accesibles a traves de metodos pero para ello se les debe de enviar un mensaje
//Todo en swift en un obejto y las tuplas no lo son porque no son inmutables

var sandra = Alumno(nombre: "SANDRA", numCuenta: "1307", edad: 22)

var daniel = sandra
sandra.edad = 22
dump(daniel)
dump(sandra)





