//: Playground - noun: a place where people can play

import UIKit

struct Empleado{
    var nombre: String
    var sueldo: Double{
        willSet{
            print("El sueldo nuevo es:\(newValue)")
            //para modificar el valor
        }
        didSet{
            print("El sueldo anterior era de: \(oldValue)")
        }
        // viejo dato es did. Sin emabargo el will y did se activan cuando existe un cambio
    }
    var impuestos: Double{
        return sueldo * 0.16
    }
//propiedades calculadas esto nos va a permiter calcular los setters y los getters
//lo que estamos haciendo es un getter porque vamos a obtner un valor
  init(nombre: String, sueldo: Double){
    self.nombre = nombre
    self.sueldo = sueldo
  }
    func trabaja(){
        print("godin trabajando")
    }
    func trabaja(en donde: String){// misma funcion que la de abajo pero la otra tiene diferente contexto aqui dice en y la otra para, tienen el mismo nombre pero diferente contexto
        print("Godin trabajando en: \(donde)")
    }
    func trabaja(para don: String){
        print("godin trabaja para:\(don)")
    }
}
var godin = Empleado(nombre: "Daniel", sueldo: 900.50)
godin.sueldo = 700
godin.trabaja(en:"la casa")// en esta fucnion estamos recibiendo un parametro de tipo string
godin.trabaja()// al llamar esta funcion no estamos recibiendo un parametro
godin.trabaja(para:"las chicas superpodeorsas")
