//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
var message = "Hola" + "mundo"
var name = "german"
message += name

let exclamationMark : Character = "!"
message += String(exclamationMark)

// interpolation

message = "Hola  mundo \(name)"

var age : Int = 20

message = "Yo soy \(name) y tengo \(age) años"
let oneThird = 1.0 / 3.0

//multiline
let multiLine = """
Esta es una multilínea
y solo escribiré 2 líneas
adios
"""
print(multiLine)

//Tuplas
let coordinates : (Int, Int) = ( 3, 4)
coordinates.1


let coordinatesNamed : (x: Int, y: Int) = (3, 5)
coordinatesNamed.x

let coordinates3D = (x:2, y:3, z:4)

let (x3, y3, z3) = coordinates3D
print (z3)

let(x4, y4, _) = coordinates3D




