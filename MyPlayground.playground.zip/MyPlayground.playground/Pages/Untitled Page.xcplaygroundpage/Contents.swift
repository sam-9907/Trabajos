//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
var ingeniero = "guapo"
ingeniero = "feo"
type(of: ingeniero)

let ingeniera = "fea"
//ingeniera = "bonita"

print("Hola mundo")

var edad = 10
var edad2 : Int = 10
var edad3 = Int(10.0)
var edad4 = 10 as Int

var decimal = 10.0

"Francisco" + "Javier"

var x = 10
var y = 2.5
x+Int(y)
Double(x)+y

var counter = 1
counter += 1
counter -= 1
counter *= 5
counter /= 2

var millon = 1_000_000
var 🦁 = "Leon"
var perrito = "🐶"


var vocal: Character="A"
type(of: vocal)


var name = "Francisco"
var age = "🎱"
var message = "Hola mundo yo me llamo \(name) y tengo sueño y tengo \(age) años"
print(message)

//TUPLAS

var tupla = (3,4,5,6)
tupla.0
tupla.3

var tupla2: (x:Int,y:Int,z:Int) = (9,8,5)
tupla2.x
tupla2.z
